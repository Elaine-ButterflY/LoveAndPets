﻿using LoveAndPets.Domain.Model.Common;
using LoveAndPets.Model.Common;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;


namespace LoveAndPets.Domain.DB
{
    public class AnimalDbContext : IdentityDbContext<User, IdentityRole<int>, int>
    {
        public AnimalDbContext(DbContextOptions<AnimalDbContext> options)
            : base(options)
        {
            Database.EnsureCreated();
        }

        ///пользователи
        public override DbSet<User> Users { get; set; }

        ///сотрудники
        public DbSet<Employee> Employee { get; set; }

        public DbSet<Animals> Animals { get; set; }

        public DbSet<Services> Services { get; set; }

        public DbSet<Doctors> Doctors { get; set; }

        public DbSet<Breeds> Breeds { get; set; }

        public DbSet<Pets> Pets { get; set; }
        public DbSet<Notes> Notes { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<User>(x =>
            {
                x.HasOne(y => y.Employee)
                .WithOne()
                .IsRequired(true);
            });
            #region Pets
            modelBuilder.Entity<Pets>(b =>
            {
                b.ToTable("Pet");
                EntityId(b);
                b.Property(x => x.PetName)
                .HasColumnName("PetName").IsRequired();
                b.Property(x => x.AnimalsEntitys)
               .HasColumnName("AnimalId").IsRequired();
                //  b.Property(x => x.BreedsEntitys)
                //.HasColumnName("BreedId").IsRequired();
                b.Property(x => x.EmployeeEntitys)
               .HasColumnName("UserId").IsRequired();
            });
            #endregion

            #region Breeds
            modelBuilder.Entity<Breeds>(b =>
            {
                b.ToTable("Breed");
                EntityId(b);
                b.Property(x => x.AnimalsEntitys)
                .HasColumnName("AnimalId").IsRequired();
                b.Property(x => x.BreedName)
                .HasColumnName("BreedName").IsRequired();
            });
            #endregion

            #region Animals
            modelBuilder.Entity<Animals>(b =>
            {
                b.ToTable("Animal");
                EntityId(b);
                b.Property(x => x.TypeName)
                .HasColumnName("TypeName").IsRequired();
            });
            #endregion

            #region Services
            modelBuilder.Entity<Services>(b =>
            {
                b.ToTable("Service");
                EntityId(b);
                b.Property(x => x.ServiceName)
                .HasColumnName("ServiceName").IsRequired();
            });
            #endregion

            #region Employee
            modelBuilder.Entity<Employee>(b =>
            {
                b.ToTable("Employees");
                EntityId(b);
                b.Property(x => x.Surname)
                .HasColumnName("Surname").IsRequired();
                b.Ignore(x => x.FullName);

            });
            #endregion

            #region Doctors
            modelBuilder.Entity<Doctors>(b =>
            {
                b.ToTable("Doctor");
                EntityId(b);
                b.Property(x => x.Surname)
                .HasColumnName("Surname").IsRequired();
                b.Property(x => x.ServicesEntitys)
               .HasColumnName("ServiceId").IsRequired();

            });
            #endregion

            #region Notes
            modelBuilder.Entity<Notes>(b =>
            {
                b.ToTable("Note");
                EntityId(b);
                b.Property(x => x.DoctorsEntitys)
                .HasColumnName("DoctorId").IsRequired();
                b.Property(x => x.EmployeeEntitys)
               .HasColumnName("UserId").IsRequired();
                b.Property(x => x.PetsEntitys)
               .HasColumnName("PetId").IsRequired();
                b.Property(x => x.DateAppointment)
               .HasColumnName("DateAppointment").IsRequired();
            });
            #endregion
        }

        private static void EntityId<TEntity>(EntityTypeBuilder<TEntity> builder)
            where TEntity : Entity
        {
            builder.Property(x => x.Entitys)
                .HasColumnName("Id")
                .IsRequired();
            builder.HasKey(x => x.Entitys).HasAnnotation("Npgsql:Serial", true);
        }
    }
}

