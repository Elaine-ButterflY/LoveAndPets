﻿using LoveAndPets.Model.Common;
using System.ComponentModel.DataAnnotations.Schema;

namespace LoveAndPets.Domain.Model.Common
{

    public class Doctors : Entity
    {
        /// <summary>
        /// Имя доктора
        /// </summary>
        public string FirstName { get; set; }
        /// <summary>
        /// Фамилия доктора
        /// </summary>
        public string Surname { get; set; }
        /// <summary>
        /// Отчество доктора
        /// </summary>
        public string Patronymic { get; set; }

        public string FullName
        {
            get => Surname + " " + FirstName + " " + Patronymic;
        }
        /// <summary>
        /// Индентификатор услуги, которую проводит врач
        /// </summary>
        [ForeignKey("ServicesEntitys")]
        public long ServicesEntitys { get; set; }

        public Services Services { get; set; }
    }
}
