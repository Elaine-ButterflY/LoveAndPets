﻿using System.ComponentModel.DataAnnotations;

namespace LoveAndPets.ViewModels.Account
{
    public class ListAppointmentViewModel
    {
        /// <summary>
        /// Идентификатор доктора
        /// </summary>
        [Required]
        [Display(Name = "Id доктора")]
        public string Doctor { get; set; }
        /// <summary>
        /// Идентификатор врача, к которому записываются на прием
        /// </summary>
        [Required]
        [Display(Name = "Id клиента")]
        public long Id { get; set; }
        /// <summary>
        /// Дата, на которую назначен прием
        /// </summary>
        [Required]
        [Display(Name = "Дата приема")]
        public string DateAppointment { get; set; }
    }
}
