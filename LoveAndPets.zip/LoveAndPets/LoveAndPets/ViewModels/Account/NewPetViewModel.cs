﻿using System.ComponentModel.DataAnnotations;

namespace LoveAndPets.ViewModels.Account
{
    public class NewPetViewModel
    {
        /// <summary>
        ///Кличка питомца
        /// </summary>
        [Required]
        [Display(Name = "Кличка питомца")]
        public string PetName { get; set; }
        /// <summary>
        /// Индентификатор хозяина животного
        /// </summary>
        [Required]
        [Display(Name = "Индентификатор хозяина питомца")]
        public long Employee { get; set; }
        /// <summary>
        /// Индентификатор типа животного
        /// </summary>
        [Required]
        [Display(Name = "Индентификатор типа питомца")]
        public long Animals { get; set; }
        /// <summary>
        /// Индентификатор породы животного
        /// </summary>
        [Required]
        [Display(Name = "Индентификатор породы питомца")]
        public long Breeds { get; set; }
    }
}
