﻿using System.ComponentModel.DataAnnotations;

namespace LoveAndPets.ViewModels.Account
{
    public class BreedItemViewModel
    {
        /// <summary>
        /// Идентификатор вида животного
        /// </summary>
        [Required]
        [Display(Name = "Id вида животного")]
        public long Animals { get; set; }

        /// <summary>
        /// Название вида животного
        /// </summary>
        [Required]
        [Display(Name = "Название вида животного")]

        public string TypeName { get; set; }
    }
}
