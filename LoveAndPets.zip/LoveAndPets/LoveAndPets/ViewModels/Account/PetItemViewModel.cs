﻿using System.ComponentModel.DataAnnotations;

namespace LoveAndPets.ViewModels.Account
{
    public class PetItemViewModel
    {
        /// <summary>
        /// Идентификатор типа питомца
        /// </summary>
        [Required]
        [Display(Name = "Id типа питомца")]
        public long Animal { get; set; }

        /// <summary>
        /// Название типа питомца
        /// </summary>
        [Required]
        [Display(Name = "Название  типа питомца")]

        public string TypeName { get; set; }
    }
}
