﻿using LoveAndPets.Domain.Model.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace LoveAndPets.ViewModels.Account
{
    public class PetsItemViewMode
    {
        /// <summary>
        /// Индентификатор хозяина животного
        /// </summary>
        public long EmployeeEntitys { get; set; }
        [ForeignKey("EmployeeEntitys")]
        public Employee Employee { get; set; }

        /// <summary>
        /// Идентификатор питомца
        /// </summary>
        [Required]
        [Display(Name = "Id питомца")]
        public long Pet { get; set; }

        /// <summary>
        /// Имя питомца
        /// </summary>
        [Required]
        [Display(Name = "Имя питомца")]

        public string PetName { get; set; }
    }
}
