﻿using System.ComponentModel.DataAnnotations;

namespace LoveAndPets.ViewModels.Account
{
    public class DoctorItemViewModel
    {
        /// <summary>
        /// Идентификатор услуги, предоставляемой врачом
        /// </summary>
        [Required]
        [Display(Name = "Id услуги")]
        public long Service { get; set; }

        /// <summary>
        /// Название услуги, предоставляемой врачом
        /// </summary>
        [Required]
        [Display(Name = "Название  услуги")]

        public string ServiceName { get; set; }
    }
}
