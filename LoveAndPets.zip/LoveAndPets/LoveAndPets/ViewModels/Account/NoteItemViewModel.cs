﻿using System.ComponentModel.DataAnnotations;

namespace LoveAndPets.ViewModels.Account
{
    public class NoteItemViewModel
    {

        /// <summary>
        /// Идентификатор доктора
        /// </summary>
        [Required]
        [Display(Name = "Id доктора")]
        public long Doctor { get; set; }

        /// <summary>
        /// Имя доктора
        /// </summary>
        [Required]
        [Display(Name = "Имя доктора")]

        public string DoctorName { get; set; }
    }
}
