﻿using LoveAndPets.Domain.DB;
using LoveAndPets.Domain.Model.Common;
using LoveAndPets.Exceptions.Http;
using LoveAndPets.Security.Extensions;
using LoveAndPets.ViewModels.Account;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;

namespace LoveAndPets.Controllers
{
    public class PetController : Controller
    {
        private readonly AnimalDbContext _animalDbContext;

        public PetController(AnimalDbContext animalDbContext)
        {
            _animalDbContext = animalDbContext ?? throw new ArgumentNullException(nameof(animalDbContext));
        }

        [HttpGet]
        public IActionResult AddPet()
        {
            ViewBag.ListTypeName = _animalDbContext.Animals
                .Select(x => new PetItemViewModel { TypeName = x.TypeName, Animal = x.Entitys })
                .ToList();

            return View();
        }

        [HttpPost]
        public IActionResult AddPet(NewPetViewModel model)
        {

            ViewBag.ListTypeName = _animalDbContext.Animals
               .Select(x => new PetItemViewModel { TypeName = x.TypeName, Animal = x.Entitys })
               .ToList();

            if (!ModelState.IsValid)
                return View(model);
            var user = this.GetAuthorizedUser();

            var animal = _animalDbContext.Animals
                .FirstOrDefault(x => x.Entitys == model.Animals)
                ?? throw new NotFoundException(typeof(Services), model.Animals);

            var post = new Pets
            {
                PetName = model.PetName,
                AnimalsEntitys = model.Animals,
                EmployeeEntitys = user.Id
            };

            _animalDbContext.Pets.Add(post);

            _animalDbContext.SaveChanges();

            return View(model);
        }
    }
}
