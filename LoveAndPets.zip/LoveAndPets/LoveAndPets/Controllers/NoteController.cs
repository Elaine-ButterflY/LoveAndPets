﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LoveAndPets.Security.Extensions;
using LoveAndPets.Domain.DB;
using LoveAndPets.Domain.Model.Common;
using LoveAndPets.ViewModels.Account;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace LoveAndPets.Controllers
{
    public class NoteController : Controller
    {
        private readonly AnimalDbContext _animalDbContext;

        public NoteController(AnimalDbContext animalDbContext)
        {
            _animalDbContext = animalDbContext ?? throw new ArgumentNullException(nameof(animalDbContext));
        }

        [HttpGet]
        public IActionResult AddNote()
        {
            ViewBag.ListDoctor = _animalDbContext.Doctors
                .Select(x => new NoteItemViewModel { DoctorName = x.FullName, Doctor = x.Entitys })
                .ToList();

            var user = this.GetAuthorizedUser();

            ViewBag.ListPets = _animalDbContext.Pets
                .Select(x => new PetsItemViewMode { PetName=x.PetName, Pet=x.Entitys, EmployeeEntitys=x.EmployeeEntitys })
                .Where(y=> y.EmployeeEntitys==user.Id)
                .ToList();


            return View();
        }

        [HttpPost]
        public IActionResult AddNote(NewNoteViewModel model)
        {
            
            if (!ModelState.IsValid) return View(model);

          
            var user = this.GetAuthorizedUser();
            
            var post = new Notes
            
            {
                
                 DoctorsEntitys=model.Doctors,
                 EmployeeEntitys= user.Id,
                 PetsEntitys=model.Pets,
                 DateAppointment=model.DateAppointment
            };


            _animalDbContext.Notes.Add(post);

            _animalDbContext.SaveChanges();

            return RedirectToAction("AddNote", "Note");
        }

        [HttpGet]
        public IActionResult Appointments()
        {
            
            
            var user = this.GetAuthorizedUser();


            var ListDoctors = _animalDbContext.Doctors
             .Select(x => new NoteItemViewModel { DoctorName = x.FullName, Doctor = x.Entitys })
             .ToList();

            IQueryable<ListAppointmentViewModel> appointment = _animalDbContext.Notes.Select(x => new ListAppointmentViewModel
                {
                    Id = x.EmployeeEntitys,
                    Doctor=x.DoctorsEntitys.ToString(),
                    DateAppointment = x.DateAppointment.ToString()
                   
                }).OrderByDescending(x => x.DateAppointment);

                List<string> postings = new List<string>();
                
                foreach (ListAppointmentViewModel post in appointment)
                {
                foreach (NoteItemViewModel doc in ListDoctors)
                    if (user.Id == post.Id)
                    {
                        if (doc.Doctor.ToString().Equals(post.Doctor))
                        {
                            postings.Add(post.DateAppointment);
                            postings.Add("Прием у: " + doc.DoctorName);
                            postings.Add("-----------------------------------------------");
                        }
                    }
                }
                return View(postings);
            
        }
    }
}
